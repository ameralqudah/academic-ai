import type { Metadata } from 'next';
import { getFormatter, getTranslations } from 'next-intl/server';

import { BillingActions } from '@/components/billing/billing-actions';
import { PricingSection } from '@/components/marketing/pricing-section';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardHeader } from '@/components/ui/card';
import { getEnv } from '@/config/env';
import { requirePageUser } from '@/server/auth/guards';
import { billingProvider } from '@/server/billing';
import { resolvePlanForUser } from '@/server/services/subscription.service';
import { getSummary } from '@/server/services/usage.service';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: 'billing' });
  return { title: t('title') };
}

export default async function BillingPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const user = await requirePageUser(locale);

  const t = await getTranslations({ locale, namespace: 'billing' });
  const tu = await getTranslations({ locale, namespace: 'usage' });
  const td = await getTranslations({ locale, namespace: 'dashboard' });
  const format = await getFormatter({ locale });
  const number = new Intl.NumberFormat(locale === 'ar' ? 'ar-EG' : 'en-US');

  const [plan, summary] = await Promise.all([resolvePlanForUser(user.id), getSummary(user.id)]);
  const planName = locale === 'ar' ? plan.plan.nameAr : plan.plan.nameEn;
  const provider = billingProvider();
  const env = getEnv();

  const rows = [
    { label: tu('aiRequests'), ...summary.aiRequests },
    { label: tu('generatedWords'), ...summary.generatedWords },
    { label: tu('projects'), ...summary.projects },
  ];

  return (
    <div className="flex flex-col gap-7">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-ink">{t('title')}</h1>
      </header>

      {provider.name === 'manual' && env.NODE_ENV !== 'production' ? (
        <Alert tone="info">{t('manualNotice')}</Alert>
      ) : null}

      {plan.cancelAtPeriodEnd && plan.periodEnd ? (
        <Alert tone="warning">
          {t('cancelScheduled', {
            date: format.dateTime(plan.periodEnd, { dateStyle: 'medium' }),
          })}
        </Alert>
      ) : null}

      <Card className="flex flex-col gap-5">
        <CardHeader
          title={
            <span className="flex items-center gap-2">
              {planName}
              <Badge tone={plan.isPro ? 'upgrade' : 'neutral'}>{plan.status}</Badge>
            </span>
          }
          description={
            plan.periodEnd
              ? plan.cancelAtPeriodEnd
                ? t('endsOn', { date: format.dateTime(plan.periodEnd, { dateStyle: 'medium' }) })
                : t('renewsOn', { date: format.dateTime(plan.periodEnd, { dateStyle: 'medium' }) })
              : td('stats.resetsOn', {
                  date: format.dateTime(summary.resetsAt, { dateStyle: 'medium' }),
                })
          }
        />

        <dl className="grid gap-4 sm:grid-cols-3">
          {rows.map((row) => (
            <div key={row.label} className="flex flex-col gap-1">
              <dt className="text-xs tracking-wide text-muted uppercase">{row.label}</dt>
              <dd className="tabular text-lg font-semibold text-ink">
                {row.limit < 0
                  ? td('stats.unlimited')
                  : tu('remaining', {
                      used: number.format(row.used),
                      limit: number.format(row.limit),
                    })}
              </dd>
            </div>
          ))}
        </dl>

        <BillingActions
          isPro={plan.isPro}
          cancelAtPeriodEnd={plan.cancelAtPeriodEnd}
          proPlanCode="PRO"
          supportsPortal={provider.name === 'stripe'}
        />
      </Card>

      <div className="-mx-4 sm:-mx-6 lg:-mx-8">
        <PricingSection locale={locale} currentPlan={plan} compact />
      </div>
    </div>
  );
}
