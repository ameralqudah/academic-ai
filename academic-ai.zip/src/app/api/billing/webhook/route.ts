import { billingProvider } from '@/server/billing';
import { logger } from '@/lib/logger';
import { applyBillingEvent } from '@/server/services/billing.service';

/**
 * Deliberately outside `withApi`: the payload must be read as a raw string for
 * signature verification, there is no session, and the provider's own signature
 * is the authentication. Always returns 200 on a verified event so the provider
 * does not retry a message we have already stored.
 */
export async function POST(request: Request): Promise<Response> {
  const raw = await request.text();
  const signature =
    request.headers.get('stripe-signature') ?? request.headers.get('x-webhook-signature');

  try {
    const event = await billingProvider().handleWebhook(raw, signature);
    await applyBillingEvent(event);
    return Response.json({ received: true, type: event.type });
  } catch (error) {
    logger.warn('billing.webhook.rejected', {
      error: error instanceof Error ? error.message : String(error),
    });
    return Response.json({ received: false }, { status: 400 });
  }
}
