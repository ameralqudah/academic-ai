import { getEnv } from '@/config/env';
import { logger } from '@/lib/logger';

import { ManualBillingProvider } from './manual';
import type { BillingProvider } from './provider';
import { StripeBillingProvider } from './stripe';

let cached: BillingProvider | null = null;

export function billingProvider(): BillingProvider {
  if (cached) return cached;

  const env = getEnv();

  if (env.BILLING_PROVIDER === 'stripe') {
    const stripe = new StripeBillingProvider();
    if (stripe.isConfigured()) {
      cached = stripe;
      return cached;
    }
    logger.warn('billing.stripe.unconfigured', {
      detail: 'BILLING_PROVIDER=stripe but STRIPE_SECRET_KEY is empty — falling back to manual.',
    });
  }

  cached = new ManualBillingProvider();
  return cached;
}

export type { BillingEvent, BillingProvider, CheckoutResult } from './provider';
