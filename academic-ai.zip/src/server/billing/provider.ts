/**
 * Payment gateways sit behind one interface so the subscription flow can ship,
 * and be tested, before a gateway account exists.
 *
 * `ManualBillingProvider` runs the entire upgrade / cancel flow against the
 * database. `StripeBillingProvider` implements the same four methods against
 * Stripe's API. Nothing outside this folder knows which one is active.
 */

export interface CheckoutResult {
  /** Where to send the user next. Manual billing returns an internal URL. */
  url: string;
  /** True when the plan change already happened (manual billing). */
  applied: boolean;
}

export type BillingEventType =
  | 'subscription.activated'
  | 'subscription.updated'
  | 'subscription.canceled'
  | 'payment.failed'
  | 'ignored';

export interface BillingEvent {
  type: BillingEventType;
  externalCustomerId?: string;
  externalSubscriptionId?: string;
  planCode?: string;
  periodEnd?: Date;
  userId?: string;
}

export interface BillingProvider {
  readonly name: 'manual' | 'stripe';

  /** True when the provider has the credentials it needs. */
  isConfigured(): boolean;

  createCheckout(input: {
    userId: string;
    email: string;
    planCode: string;
    locale: string;
  }): Promise<CheckoutResult>;

  createPortalSession(input: { userId: string; locale: string }): Promise<{ url: string }>;

  cancel(input: { userId: string; atPeriodEnd: boolean }): Promise<void>;

  /** Verifies the signature and maps the payload onto a `BillingEvent`. */
  handleWebhook(rawBody: string, signature: string | null): Promise<BillingEvent>;
}
