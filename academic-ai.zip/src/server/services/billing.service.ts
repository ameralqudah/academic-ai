import { billingProvider, type BillingEvent } from '@/server/billing';
import { logger } from '@/lib/logger';
import { AppError } from '@/server/http/errors';
import * as plansRepo from '@/server/repositories/plans.repository';
import * as usersRepo from '@/server/repositories/users.repository';

export async function startCheckout(input: {
  userId: string;
  planCode: string;
  locale: string;
}): Promise<{ url: string; applied: boolean }> {
  const user = await usersRepo.findById(input.userId);
  if (!user) throw AppError.notFound('user');

  const provider = billingProvider();
  const result = await provider.createCheckout({
    userId: input.userId,
    email: user.email,
    planCode: input.planCode,
    locale: input.locale,
  });

  logger.info('billing.checkout.started', {
    provider: provider.name,
    planCode: input.planCode,
    applied: result.applied,
  });

  return result;
}

export async function openPortal(userId: string, locale: string): Promise<{ url: string }> {
  return billingProvider().createPortalSession({ userId, locale });
}

export async function cancelSubscription(
  userId: string,
  atPeriodEnd: boolean,
): Promise<void> {
  await billingProvider().cancel({ userId, atPeriodEnd });
  logger.info('billing.subscription.canceled', { atPeriodEnd });
}

/** Applies a verified provider event to the database. Idempotent by design. */
export async function applyBillingEvent(event: BillingEvent): Promise<void> {
  if (event.type === 'ignored' || !event.userId) return;

  const existing = await plansRepo.findSubscriptionByUser(event.userId);

  if (event.type === 'subscription.canceled') {
    const fallback = await plansRepo.findDefaultPlan();
    if (existing && fallback) {
      await plansRepo.updateSubscription(existing.subscription.id, {
        planId: fallback.id,
        status: 'CANCELED',
        canceledAt: new Date(),
        periodEnd: null,
      });
    }
    return;
  }

  if (event.type === 'payment.failed') {
    if (existing) {
      await plansRepo.updateSubscription(existing.subscription.id, { status: 'PAST_DUE' });
    }
    return;
  }

  const plan = event.planCode
    ? await plansRepo.findPlanByCode(event.planCode)
    : existing
      ? existing.plan
      : await plansRepo.findDefaultPlan();

  if (!plan) return;

  const values = {
    planId: plan.id,
    status: 'ACTIVE' as const,
    periodStart: new Date(),
    periodEnd: event.periodEnd ?? null,
    cancelAtPeriodEnd: false,
    canceledAt: null,
    provider: billingProvider().name,
    externalCustomerId: event.externalCustomerId ?? null,
    externalSubscriptionId: event.externalSubscriptionId ?? null,
  };

  if (existing) {
    await plansRepo.updateSubscription(existing.subscription.id, values);
  } else {
    await plansRepo.ensureSubscription({ userId: event.userId, ...values });
  }
}
