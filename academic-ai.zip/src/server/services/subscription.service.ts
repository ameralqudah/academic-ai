import type { SubscriptionPlan } from '@/server/db/schema';
import { AppError } from '@/server/http/errors';
import * as plansRepo from '@/server/repositories/plans.repository';

export const UNLIMITED = -1;

export interface ResolvedPlan {
  plan: SubscriptionPlan;
  status: 'ACTIVE' | 'TRIALING' | 'PAST_DUE' | 'CANCELED';
  periodEnd: Date | null;
  cancelAtPeriodEnd: boolean;
  isPro: boolean;
}

/**
 * Every user always has a plan. If a subscription row is missing (social sign-in,
 * data imported from elsewhere), the default plan is attached on read rather than
 * leaving the caller to handle a null.
 */
export async function resolvePlanForUser(userId: string): Promise<ResolvedPlan> {
  const existing = await plansRepo.findSubscriptionByUser(userId);

  if (existing) {
    return {
      plan: existing.plan,
      status: existing.subscription.status,
      periodEnd: existing.subscription.periodEnd,
      cancelAtPeriodEnd: existing.subscription.cancelAtPeriodEnd,
      isPro: existing.plan.priceCents > 0 && existing.subscription.status !== 'CANCELED',
    };
  }

  const fallback = await plansRepo.findDefaultPlan();
  if (!fallback) {
    throw new AppError(
      'INTERNAL',
      'No default subscription plan is configured. Run the database seed.',
      'لا توجد خطة اشتراك افتراضية. شغّل ملف البذور (seed).',
    );
  }

  await plansRepo.ensureSubscription({ userId, planId: fallback.id, status: 'ACTIVE' });

  return {
    plan: fallback,
    status: 'ACTIVE',
    periodEnd: null,
    cancelAtPeriodEnd: false,
    isPro: false,
  };
}

export async function attachDefaultPlan(userId: string): Promise<void> {
  const fallback = await plansRepo.findDefaultPlan();
  if (!fallback) return;
  await plansRepo.ensureSubscription({ userId, planId: fallback.id, status: 'ACTIVE' });
}

/** `-1` means unlimited everywhere in the app. */
export function isUnlimited(limit: number): boolean {
  return limit === UNLIMITED;
}

export function hasToolAccess(plan: SubscriptionPlan, key: string): boolean {
  const access = plan.toolAccess ?? {};
  return access[key] === true;
}

export async function listPublicPlans() {
  return plansRepo.listActivePlans();
}
