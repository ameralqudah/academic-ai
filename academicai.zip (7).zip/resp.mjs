import { chromium } from '@playwright/test';
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const sizes = [
  { name: 'phone-390',  width: 390,  height: 844 },
  { name: 'phone-360',  width: 360,  height: 740 },
  { name: 'tablet-768', width: 768,  height: 1024 },
  { name: 'laptop-1366',width: 1366, height: 768 },
];
for (const s of sizes) {
  const ctx = await browser.newContext({ viewport: { width: s.width, height: s.height }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  await page.goto('http://127.0.0.1:3999/ar', { waitUntil: 'networkidle' });
  const overflow = await page.evaluate(() => ({
    scrollW: document.documentElement.scrollWidth,
    clientW: document.documentElement.clientWidth,
    offenders: [...document.querySelectorAll('*')]
      .filter(el => el.getBoundingClientRect().right > document.documentElement.clientWidth + 1)
      .slice(0, 5).map(el => el.tagName + '.' + (el.className?.toString().slice(0, 40) || '')),
  }));
  console.log(`${s.name.padEnd(13)} scrollW=${overflow.scrollW} clientW=${overflow.clientW} ` +
              `${overflow.scrollW <= overflow.clientW + 1 ? 'OK — no horizontal overflow' : 'OVERFLOW: ' + JSON.stringify(overflow.offenders)}`);
  if (s.name === 'phone-390') await page.screenshot({ path: '/tmp/shot-phone.png', fullPage: false });
  await ctx.close();
}
await browser.close();
