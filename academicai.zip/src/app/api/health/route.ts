import { sql } from 'drizzle-orm';

import { getEnv } from '@/config/env';
import { resolveProvider } from '@/ai/registry';
import { billingProvider } from '@/server/billing';
import { db } from '@/server/db';
import { emailProvider } from '@/server/email';
import * as plansRepo from '@/server/repositories/plans.repository';
import { rateLimitStoreName } from '@/server/http/rate-limit';

export const dynamic = 'force-dynamic';

/**
 * Post-deploy smoke check. Reports whether each dependency is actually wired,
 * never what it is wired with — no key, URL, or connection string is exposed.
 *
 *   curl https://<your-app>/api/health
 */
export async function GET(): Promise<Response> {
  const checks: Record<string, unknown> = {};
  let healthy = true;

  // Database + migrations + seed, in one round trip.
  try {
    const [row] = await db.execute<{ tables: number }>(
      sql`select count(*)::int as tables from information_schema.tables where table_schema = 'public'`,
    );
    const plans = await plansRepo.listActivePlans();
    const hasDefault = plans.some((plan) => plan.isDefault);

    checks.database = {
      connected: true,
      tables: Number(row?.tables ?? 0),
      plansSeeded: plans.length,
      defaultPlan: hasDefault,
    };
    if (!hasDefault) healthy = false;
  } catch (error) {
    healthy = false;
    checks.database = {
      connected: false,
      error: error instanceof Error ? error.message.slice(0, 200) : 'unknown',
    };
  }

  try {
    const env = getEnv();
    checks.auth = { secretConfigured: env.AUTH_SECRET.length >= 16, googleEnabled: Boolean(env.AUTH_GOOGLE_ID) };

    const ai = await resolveProvider();
    checks.ai = { provider: ai.name, model: ai.model, configured: ai.isConfigured() };
    if (!ai.isConfigured()) healthy = false;

    const mail = emailProvider();
    checks.email = { provider: mail.name, deliversRealEmail: mail.name !== 'console' };
    if (env.NODE_ENV === 'production' && mail.name === 'console') healthy = false;

    const billing = billingProvider();
    checks.billing = {
      provider: billing.name,
      configured: billing.isConfigured(),
      takesRealPayments: billing.takesRealPayments,
    };
    checks.rateLimit = { store: rateLimitStoreName() };
    checks.environment = env.NODE_ENV;
  } catch (error) {
    healthy = false;
    checks.config = {
      valid: false,
      error: error instanceof Error ? error.message.slice(0, 300) : 'unknown',
    };
  }

  return Response.json(
    { status: healthy ? 'ok' : 'degraded', checks, checkedAt: new Date().toISOString() },
    { status: healthy ? 200 : 503, headers: { 'cache-control': 'no-store' } },
  );
}
